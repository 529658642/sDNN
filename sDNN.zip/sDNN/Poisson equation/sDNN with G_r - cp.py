# -*- coding: utf-8 -*-
"""
Created on Fri Apr 26 16:28:07 2024

@author: HP
"""



import sys
sys.path.insert(0, '../../Utilities/')
import tensorflow as tf
import numpy as np
from pyDOE import lhs
import time
from scipy.io import savemat
nu = np.pi

r=1001
# r=2002
# r=3003
# r=4004
# r=5005

N_u = 100
N_f = 100
layers = [2, 5, 10, 5, 1]


def solution(X, T):
    return np.cos(nu*X)*np.cos(nu*T)  


t1 = np.linspace(0, 2, 201)
x1 = np.linspace(0, 2, 201)
t2 = np.linspace(0, 2, 201)
x2 = np.linspace(-2, 0, 201)
t3 = np.linspace(-2, 0, 201)
x3 = np.linspace(-2, 0, 201)
t4 = np.linspace(-2, 0, 201)
x4 = np.linspace(0, 2, 201)
X1,  T1 = np.meshgrid(x1, t1)
X2,  T2 = np.meshgrid(x2, t2)
X3,  T3 = np.meshgrid(x3, t3)
X4,  T4 = np.meshgrid(x4, t4)


X1_star = np.hstack((X1.flatten()[:, None], T1.flatten()[:, None]))
X2_star = np.hstack((X2.flatten()[:, None], T2.flatten()[:, None]))
X3_star = np.hstack((X3.flatten()[:, None], T3.flatten()[:, None]))
X4_star = np.hstack((X4.flatten()[:, None], T4.flatten()[:, None]))
u1_star = solution(X1_star[:,0:1], X1_star[:,1:2])
u2_star = solution(X2_star[:,0:1], X2_star[:,1:2])
u3_star = solution(X3_star[:,0:1], X3_star[:,1:2])
u4_star = solution(X4_star[:,0:1], X4_star[:,1:2])


x11, t11, u11 = [], [], []
x12, t12, u12 = [], [], []

for i in range(X1_star.shape[0]):
    if X1_star[i, 0] - X1_star[i, 1] > 0:
        x11.append(X1_star[i, 0]), t11.append(X1_star[i, 1]), u11.append(
            solution(X1_star[i, 0], X1_star[i, 1]))
    elif X1_star[i, 0] - X1_star[i, 1] < 0:
        x12.append(X1_star[i, 0]), t12.append(X1_star[i, 1]), u12.append(
            solution(X1_star[i, 0], X1_star[i, 1]))


x11, t11, u11, x12, t12, u12 = np.array(x11), np.array(
    t11), np.array(u11), np.array(x12), np.array(t12), np.array(u12)
X11_star = np.hstack((x11.flatten()[:, None], t11.flatten()[:, None]))
X12_star = np.hstack((x12.flatten()[:, None], t12.flatten()[:, None]))

u11_star = u11.flatten()[:, None]
u12_star = u12.flatten()[:, None]
Exact11 = solution(x11, t11)
Exact12 = solution(x12, t12)


x21, t21, u21 = [], [], []
x22, t22, u22 = [], [], []

for i in range(X2_star.shape[0]):
    if X2_star[i, 0] + X2_star[i, 1] > 0:
        x21.append(X2_star[i, 0]), t21.append(X2_star[i, 1]), u21.append(
            solution(X2_star[i, 0], X2_star[i, 1]))
    elif X2_star[i, 0] + X2_star[i, 1] < 0:
        x22.append(X2_star[i, 0]), t22.append(X2_star[i, 1]), u22.append(
            solution(X2_star[i, 0], X2_star[i, 1]))


x21, t21, u21, x22, t22, u22 = np.array(x21), np.array(
    t21), np.array(u21), np.array(x22), np.array(t22), np.array(u22)
X21_star = np.hstack((x21.flatten()[:, None], t21.flatten()[:, None]))
X22_star = np.hstack((x22.flatten()[:, None], t22.flatten()[:, None]))

u21_star = u21.flatten()[:, None]
u22_star = u22.flatten()[:, None]
Exact21 = solution(x21, t21)
Exact22 = solution(x22, t22)


x31, t31, u31 = [], [], []
x32, t32, u32 = [], [], []

for i in range(X3_star.shape[0]):
    if X3_star[i, 0] - X3_star[i, 1] < 0:
        x31.append(X3_star[i, 0]), t31.append(X3_star[i, 1]), u31.append(
            solution(X3_star[i, 0], X3_star[i, 1]))
    elif X3_star[i, 0] - X3_star[i, 1] > 0:
        x32.append(X3_star[i, 0]), t32.append(X3_star[i, 1]), u32.append(
            solution(X3_star[i, 0], X3_star[i, 1]))


x31, t31, u31, x32, t32, u32 = np.array(x31), np.array(
    t31), np.array(u31), np.array(x32), np.array(t32), np.array(u32)
X31_star = np.hstack((x31.flatten()[:, None], t31.flatten()[:, None]))
X32_star = np.hstack((x32.flatten()[:, None], t32.flatten()[:, None]))

u31_star = u31.flatten()[:, None]
u32_star = u32.flatten()[:, None]
Exact31 = solution(x31, t31)
Exact32 = solution(x32, t32)


x41, t41, u41 = [], [], []
x42, t42, u42 = [], [], []

for i in range(X4_star.shape[0]):
    if X4_star[i, 0] + X4_star[i, 1] < 0:
        x41.append(X4_star[i, 0]), t41.append(X4_star[i, 1]), u41.append(
            solution(X4_star[i, 0], X4_star[i, 1]))
    elif X4_star[i, 0] + X4_star[i, 1] > 0:
        x42.append(X4_star[i, 0]), t42.append(X4_star[i, 1]), u42.append(
            solution(X4_star[i, 0], X4_star[i, 1]))


x41, t41, u41, x42, t42, u42 = np.array(x41), np.array(
    t41), np.array(u41), np.array(x42), np.array(t42), np.array(u42)
X41_star = np.hstack((x41.flatten()[:, None], t41.flatten()[:, None]))
X42_star = np.hstack((x42.flatten()[:, None], t42.flatten()[:, None]))

u41_star = u41.flatten()[:, None]
u42_star = u42.flatten()[:, None]
Exact41 = solution(x41, t41)
Exact42 = solution(x42, t42)


X222_star = np.hstack((t11.flatten()[:, None], x11.flatten()[:, None]))
X333_star = np.hstack((t11.flatten()[:, None], -x11.flatten()[:, None]))

X12metric_star = np.hstack((t11.flatten()[:, None], x11.flatten()[:, None]))
X21metric_star = np.hstack((t11.flatten()[:, None], -x11.flatten()[:, None]))
X22metric_star = np.hstack((-x11.flatten()[:, None], t11.flatten()[:, None]))


np.random.seed(r)
tf.set_random_seed(r)

class PhysicsInformedNN:
    # Initialize the class
    def __init__(self, X_u, u, X_f, layers, lb, ub):
        #boundary conditions
        self.lb = lb
        self.ub = ub
    
        
        #data
        self.x_u = X_u[:,0:1]
        self.t_u = X_u[:,1:2]
        
        self.x_f = X_f[:,0:1]
        self.t_f = X_f[:,1:2]
        
        self.u = u
        
        self.layers = layers
        self.loss_set =[]
        
        # Initialize NNs
        self.weights, self.biases = self.initialize_NN(layers)
        
        # tf placeholders and graph
        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                     log_device_placement=True))
        
        self.x_u_tf = tf.placeholder(tf.float32, shape=[None, self.x_u.shape[1]])
        self.t_u_tf = tf.placeholder(tf.float32, shape=[None, self.t_u.shape[1]])        
        self.u_tf = tf.placeholder(tf.float32, shape=[None, self.u.shape[1]])
        
        self.x_f_tf = tf.placeholder(tf.float32, shape=[None, self.x_f.shape[1]])
        self.t_f_tf = tf.placeholder(tf.float32, shape=[None, self.t_f.shape[1]])        
                
        self.u_pred = self.net_u(self.x_u_tf, self.t_u_tf)
        self.f_pred = self.net_f(self.x_f_tf, self.t_f_tf)         
        
        self.loss = tf.reduce_mean(tf.square(self.u_tf - self.u_pred))  + \
                    tf.reduce_mean(tf.square(self.f_pred))
               

        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss, 
                                                                method = 'L-BFGS-B', 
                                                                options = {'maxiter': 50000,
                                                                           'maxfun': 50000,
                                                                           'maxcor': 50,
                                                                           'maxls': 50,
                                                                           'ftol' : 1.0 * np.finfo(float).eps})
        
        self.optimizer_Adam = tf.train.AdamOptimizer()
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)
        
        init = tf.global_variables_initializer()
        self.sess.run(init)

    def initialize_NN(self, layers):        
        weights = []
        biases = []
        num_layers = len(layers) 
        for l in range(0,num_layers-1): 
            if l==0 or l == num_layers-2:
                W = self.xavier_init(size=[layers[l], layers[l+1]])
            else:
                W = self.xavier_init(size=[layers[l]*4, (layers[l+1])])
            b = tf.Variable(tf.zeros([1,layers[l+1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W) 
            biases.append(b)  
        return weights, biases
        
    def xavier_init(self, size):
        in_dim = size[0] 
        out_dim = size[1]
        xavier_stddev = np.sqrt(2/(in_dim + out_dim))
        return tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)
    
    def get_initial(self):
        initial_weights, initial_biases = self.sess.run([self.weights, self.biases])
        return initial_weights, initial_biases
    
    def neural_net(self, X, weights, biases):
        num_layers = len(weights) + 1
        H = X
        for l in range(0,num_layers-2):
            if l == 0:
                W = weights[l] 
                b = biases[l] 
                W1 = tf.matmul(W, BM1)
                W2 = tf.matmul(BM5, tf.matmul(W, BM2))
                W3 = tf.matmul(BM6, tf.matmul(W, BM3))
                W4 = tf.matmul(BM7, tf.matmul(W, BM4))
                W = tf.add(tf.add(tf.add(W1, W2), W3), W4)
                b = tf.matmul(b, BM10)
                H = tf.tanh(tf.add(tf.matmul(H,W), b)) 
            elif l == 1:
                W = weights[l] 
                b = biases[l] 
                W1 = tf.matmul(W, BM13)
                W2 = tf.matmul(BM8, tf.matmul(W, BM14))
                W3 = tf.matmul(BM11, tf.matmul(W, BM15))
                W4 = tf.matmul(BM12, tf.matmul(W, BM16))
                W = tf.add(tf.add(tf.add(W1, W2), W3), W4)
                b = tf.matmul(b, BM17)
                H = tf.tanh(tf.add(tf.matmul(H,W), b)) 
            elif l == 2:
                W = weights[l] 
                b = biases[l] 
                W1 = tf.matmul(W, BM1)
                W2 = tf.matmul(BM18, tf.matmul(W, BM2))
                W3 = tf.matmul(BM19, tf.matmul(W, BM3))
                W4 = tf.matmul(BM20, tf.matmul(W, BM4))
                W = tf.add(tf.add(tf.add(W1, W2), W3), W4)
                b = tf.matmul(b, BM10)
                H = tf.tanh(tf.add(tf.matmul(H, W), b)) 
        W = weights[-1] 
        b = biases[-1] 
        Y = tf.add(tf.matmul(H, tf.matmul(BM9, W)), b)
        return Y
    
    def net_u(self, x, t):
        u = self.neural_net(tf.concat([x,t],1), self.weights, self.biases)
        return u
    
    def net_f(self, x,t):
        u = self.net_u(x, t)
        u_t = tf.gradients(u, t)[0]
        u_x = tf.gradients(u, x)[0]
        u_tt = tf.gradients(u_t, t)[0]
        u_xx = tf.gradients(u_x, x)[0]
        f = u_tt + u_xx + 2*(nu**2)*(tf.cos(nu*x)*tf.cos(nu*t)) 
        return f
    
    def callback(self, loss):
        print('Loss:', loss)
        self.loss_set.append(loss)
    
    
    
    def train(self, nIter):
        tf_dict = {self.x_u_tf: self.x_u, self.t_u_tf: self.t_u, self.u_tf: self.u,
                    self.x_f_tf: self.x_f, self.t_f_tf: self.t_f}    
        for it in range(nIter):
            self.sess.run(self.train_op_Adam, tf_dict)
            
            # Print
            if it % 10 == 0:
                loss_value = self.sess.run(self.loss, tf_dict)
                print('It: %d, Loss: %.3e' % 
                      (it, loss_value))
                                                                                                                          
        self.optimizer.minimize(self.sess, 
                                feed_dict = tf_dict,         
                                fetches = [self.loss], 
                                loss_callback = self.callback)   
                                      
        loss_set = self.loss_set
        return  loss_set
         
    
    def predict(self, X_star):
                
        u_star = self.sess.run(self.u_pred, {self.x_u_tf: X_star[:,0:1], self.t_u_tf: X_star[:,1:2]})  
        f_star = self.sess.run(self.f_pred, {self.x_f_tf: X_star[:,0:1], self.t_f_tf: X_star[:,1:2]})
               
        return u_star, f_star



identity_matrix  = tf.eye(layers[1], dtype=tf.float32)
zero_matrix = tf.zeros((layers[1], layers[1]), dtype=tf.float32)

BM1 = tf.concat([identity_matrix, zero_matrix, zero_matrix, zero_matrix], axis=1)
BM2 = tf.concat([zero_matrix, identity_matrix, zero_matrix, zero_matrix], axis=1)
BM3 = tf.concat([zero_matrix, zero_matrix, identity_matrix, zero_matrix], axis=1)
BM4 = tf.concat([zero_matrix, zero_matrix, zero_matrix, identity_matrix], axis=1)
BM5 = np.zeros((2, 2), dtype=int)
BM5[0, 1] = 1
BM5[1, 0] = -1
BM5 = BM5.astype(np.float32)
BM6 = -tf.eye(2, dtype=tf.float32)
BM7 = np.zeros((2, 2), dtype=int)
BM7[0, 1] = -1
BM7[1, 0] = 1
BM7 = BM7.astype(np.float32)
matrix_size1 = layers[1]
BM8 = np.zeros((4*matrix_size1, 4*matrix_size1), dtype=int)
BM8[:matrix_size1, 3*matrix_size1:] = np.eye(matrix_size1)
BM8[matrix_size1:2*matrix_size1, :matrix_size1] = np.eye(matrix_size1)
BM8[2*matrix_size1:3*matrix_size1, matrix_size1:2*matrix_size1] = np.eye(matrix_size1)
BM8[3*matrix_size1:, 2*matrix_size1:3*matrix_size1] = np.eye(matrix_size1)
BM8 = BM8.astype(np.float32)
BM9 = tf.concat([identity_matrix, identity_matrix, identity_matrix, identity_matrix], axis=0)
BM10 = tf.concat([identity_matrix, identity_matrix, identity_matrix, identity_matrix], axis=1)
BM11 = np.dot(BM8, BM8)
BM12 = np.dot(BM11, BM8)

identity_matrix  = tf.eye(layers[2], dtype=tf.float32)
zero_matrix = tf.zeros((layers[2], layers[2]), dtype=tf.float32)
BM13 = tf.concat([identity_matrix, zero_matrix, zero_matrix, zero_matrix], axis=1)
BM14 = tf.concat([zero_matrix, identity_matrix, zero_matrix, zero_matrix], axis=1)
BM15 = tf.concat([zero_matrix, zero_matrix, identity_matrix, zero_matrix], axis=1)
BM16 = tf.concat([zero_matrix, zero_matrix, zero_matrix, identity_matrix], axis=1)
BM17 = tf.concat([identity_matrix, identity_matrix, identity_matrix, identity_matrix], axis=1)
matrix_size2 = layers[2]
BM18 = np.zeros((4*matrix_size2, 4*matrix_size2), dtype=int)
BM18[:matrix_size2, 3*matrix_size2:] = np.eye(matrix_size2)
BM18[matrix_size2:2*matrix_size2, :matrix_size2] = np.eye(matrix_size2)
BM18[2*matrix_size2:3*matrix_size2, matrix_size2:2*matrix_size2] = np.eye(matrix_size2)
BM18[3*matrix_size2:, 2*matrix_size2:3*matrix_size2] = np.eye(matrix_size2)
BM18 = BM18.astype(np.float32)
BM19 = np.dot(BM18, BM18)
BM20 = np.dot(BM19, BM18)


# Doman bounds
lb = X11_star.min(0)
ub = X11_star.max(0)


#initIal and boundary
xx11 = x1
tt11 = t1
tt11[:] = 0
uu11 = solution(xx11, tt11).flatten()[:, None]
xx11 = np.hstack((xx11.flatten()[:, None], tt11.flatten()[:, None]))

xx12 = x1
tt12 = np.linspace(0, 2, 201)
xx12[:] = 2
uu12 = solution(xx12, tt12).flatten()[:, None]
xx12 = np.hstack((xx12.flatten()[:, None], tt12.flatten()[:, None]))

xx13 = np.linspace(0, 2, 201)
tt13 = xx13
uu13 = solution(xx13, tt13).flatten()[:, None]
xx13 = np.hstack((xx13.flatten()[:, None], tt13.flatten()[:, None]))


X_u_train = np.vstack([xx11, xx12, xx13])
u_train = np.vstack([uu11, uu12, uu13])
X_f_train = lb + (ub-lb)*lhs(2, N_f)
x_f_train, t_f_train = [], []

for i in range(X_f_train.shape[0]):
    x, t = X_f_train[i, 0], X_f_train[i, 1]
    if x > 0 and t > 0 and t < x:
        x_f_train.append(x)
        t_f_train.append(t)


x_f_train, t_f_train = np.array(x_f_train), np.array(t_f_train)
X_f_train = np.hstack(
    (x_f_train.flatten()[:, None], t_f_train.flatten()[:, None]))


X_f_train = np.vstack((X_f_train, X_u_train))
idx = np.random.choice(X_u_train.shape[0], N_u, replace=False)
X_u_train = X_u_train[idx, :]
u_train = u_train[idx, :]


model = PhysicsInformedNN(X_u_train, u_train, X_f_train, layers, lb, ub)
initial_weights, initial_biases = model.get_initial()
start_time = time.time()
loss_set = model.train(0)
elapsed = time.time() - start_time
print('Training time: %.4f' % (elapsed))


u11_pred, f11_pred = model.predict(X11_star)
u12_pred, f12_pred = model.predict(X12_star)
u21_pred, f21_pred = model.predict(X21_star)
u22_pred, f22_pred = model.predict(X22_star)
u31_pred, f31_pred = model.predict(X31_star)
u32_pred, f32_pred = model.predict(X32_star)
u41_pred, f41_pred = model.predict(X41_star)
u42_pred, f42_pred = model.predict(X42_star)
u12metric_pred, f12metric_pred = model.predict(X12metric_star)
u21metric_pred, f21metric_pred = model.predict(X21metric_star)
u22metric_pred, f22metric_pred = model.predict(X22metric_star)
S12 = np.linalg.norm(u11_pred - u12metric_pred, 2)/np.linalg.norm(u11_pred, 2)
S21 = np.linalg.norm(u11_pred - u21metric_pred, 2)/np.linalg.norm(u11_pred, 2)
S22 = np.linalg.norm(u11_pred - u22metric_pred, 2)/np.linalg.norm(u11_pred, 2)



error_u11 = np.linalg.norm(u11_star - u11_pred, 2)/np.linalg.norm(u11_star, 2)
error_u12 = np.linalg.norm(u12_star - u12_pred, 2)/np.linalg.norm(u12_star, 2)
error_u21 = np.linalg.norm(u21_star - u21_pred, 2)/np.linalg.norm(u21_star, 2)
error_u22 = np.linalg.norm(u22_star - u22_pred, 2)/np.linalg.norm(u22_star, 2)
error_u31 = np.linalg.norm(u31_star - u31_pred, 2)/np.linalg.norm(u31_star, 2)
error_u32 = np.linalg.norm(u32_star - u32_pred, 2)/np.linalg.norm(u32_star, 2)
error_u41 = np.linalg.norm(u41_star - u41_pred, 2)/np.linalg.norm(u41_star, 2)
error_u42 = np.linalg.norm(u42_star - u42_pred, 2)/np.linalg.norm(u42_star, 2)


print('Error u11: %e' % (error_u11))
print('Error u12: %e' % (error_u12))
print('Error u21: %e' % (error_u21))
print('Error u22: %e' % (error_u22))
print('Error u31: %e' % (error_u31))
print('Error u32: %e' % (error_u32))
print('Error u41: %e' % (error_u41))
print('Error u42: %e' % (error_u42))
print('S12: %e' % (S12))
print('S21: %e' % (S21))
print('S22: %e' % (S22))

trained_weights, trained_biases = model.sess.run([model.weights, model.biases])


# Error11 = np.abs(u11_star - u11_pred)
# Error12 = np.abs(u12_star - u12_pred)
# Error21 = np.abs(u21_star - u21_pred)
# Error22 = np.abs(u22_star - u22_pred)
# Error31 = np.abs(u31_star - u31_pred)
# Error32 = np.abs(u32_star - u32_pred)
# Error41 = np.abs(u41_star - u41_pred)
# Error42 = np.abs(u42_star - u42_pred)

# tttt = np.linspace(-2, 2, 201)
# xxxx = 1.5
# Exact = solution(xxxx, tttt)
# XXXX_star = np.column_stack((np.full(tttt.shape, xxxx), tttt))
# u_pred, f_pred = model.predict(XXXX_star)

# tttt = 1.5
# xxxx = np.linspace(-2, 2, 201)
# Exact = solution(xxxx, tttt)
# XXXX_star = np.column_stack((xxxx, np.full(xxxx.shape, tttt)))
# u_pred, f_pred = model.predict(XXXX_star)

