# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 00:47:28 2024

@author: HP
"""

import sys
sys.path.insert(0, '../../Utilities/')
import tensorflow as tf
import numpy as np
import time

A = 20
r=234
layers = [1, 20, 20, 20, 1] 



def solution(X):
    return (1-(1/2)*X**2)*np.cos(A*(X + (1/2)*X**3))


x1 = np.linspace(-1, 0, 101)
x2 = np.linspace(0, 1, 101)
u1 = solution(x1)
u2 = solution(x2)
Exact1 = u1
Exact2 = u2    
u1_star = Exact1
u2_star = Exact2



np.random.seed(r)
tf.set_random_seed(r)

class PhysicsInformedNN:
    # Initialize the class
    def __init__(self, X_u, u, layers, lb, ub):
        #boundary conditions
        self.lb = lb
        self.ub = ub
    
        
        #data
        self.x_u = X_u[:]
        
        
        self.u = u
        
        self.layers = layers
        self.loss_set =[]
        
        # Initialize NNs
        self.weights, self.biases = self.initialize_NN(layers)
        
        # tf placeholders and graph
        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                     log_device_placement=True))
        
        self.x_u_tf = tf.placeholder(tf.float32, shape=[None, 1])
        self.u_tf = tf.placeholder(tf.float32, shape=[None, 1])

      
        self.u_pred = self.net_u(self.x_u_tf)

        self.loss = tf.reduce_mean(tf.square(self.u_tf - self.u_pred))  


        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss, 
                                                                method = 'L-BFGS-B', 
                                                                options = {'maxiter': 50000,
                                                                           'maxfun': 50000,
                                                                           'maxcor': 50,
                                                                           'maxls': 50,
                                                                           'ftol' : 1.0 * np.finfo(float).eps})
        
        self.optimizer_Adam = tf.train.AdamOptimizer()
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)
        
        init = tf.global_variables_initializer()
        self.sess.run(init)

    def initialize_NN(self, layers):        
        weights = []
        biases = []
        num_layers = len(layers) 
        for l in range(0,num_layers-1): 
            if l==0 or l == num_layers-2:
                W = self.xavier_init(size=[layers[l], layers[l+1]])
            else:
                W = self.xavier_init(size=[layers[l]*2, (layers[l+1])])
            b = tf.Variable(tf.zeros([1,layers[l+1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W) 
            biases.append(b)  
        return weights, biases
        
    def xavier_init(self, size):
        in_dim = size[0] 
        out_dim = size[1]
        xavier_stddev = np.sqrt(2/(in_dim + out_dim))
        return tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)
    
    def get_initial(self):
        initial_weights, initial_biases = self.sess.run([self.weights, self.biases])
        return initial_weights, initial_biases
    
    def neural_net(self, X, weights, biases):
        num_layers = len(weights) + 1
        H = X
        for l in range(0,num_layers-2):
            if l == 0:
                W = weights[l] 
                b = biases[l] 
                b = tf.matmul(b, BM6)
                H = tf.tanh(tf.add(tf.matmul(H, tf.matmul(W,BM1)), b)) 
            else:
                W = weights[l] 
                b = biases[l] 
                b = tf.matmul(b, BM6)
                W = tf.add(tf.matmul(W, BM2), tf.matmul(BM3, tf.matmul(W,BM4)))
                H = tf.tanh(tf.add(tf.matmul(H, W), b)) 
        W = weights[-1] 
        b = biases[-1] 
        Y = tf.matmul(H, tf.matmul(BM5, W))
        return Y
    
    def net_u(self, x):
        u = self.neural_net([x], self.weights, self.biases)
        return u
    

    
    def callback(self, loss):
        print('Loss:', loss)
        self.loss_set.append(loss)
    
    
    
    def train(self, nIter):
        tf_dict = {self.x_u_tf: self.x_u, self.u_tf: self.u}    
        for it in range(nIter):
            self.sess.run(self.train_op_Adam, tf_dict)
            
            # Print
            if it % 10 == 0:
                loss_value = self.sess.run(self.loss, tf_dict)
                print('It: %d, Loss: %.3e' % 
                      (it, loss_value))
                                                                                                                          
        self.optimizer.minimize(self.sess, 
                                feed_dict = tf_dict,         
                                fetches = [self.loss], 
                                loss_callback = self.callback)   
                                      
        loss_set = self.loss_set
        return  loss_set
         
    
    def predict(self, X_star):
                
        u_star = self.sess.run(self.u_pred, {self.x_u_tf: X_star[:]})  
               
        return u_star
    
    
    

identity_matrix  = tf.eye(layers[1], dtype=tf.float32)
zero_matrix = tf.zeros((layers[1], layers[1]), dtype=tf.float32)

BM1 = tf.concat([identity_matrix, -identity_matrix], axis=1)
BM2 = tf.concat([identity_matrix, zero_matrix], axis=1)
BM3 = tf.concat([tf.concat([zero_matrix, identity_matrix], axis=1),
                 tf.concat([identity_matrix, zero_matrix], axis=1)], axis=0)
BM4 = tf.concat([zero_matrix, identity_matrix], axis=1)
BM5 = tf.concat([identity_matrix, identity_matrix], axis=0)#偶
BM6 = tf.concat([identity_matrix, identity_matrix], axis=1)



# Doman bounds
lb = x1.min(0)
ub = x1.max(0)  

    
X_u_train = np.array([x1]).T  
u_train = np.array([u1]).T  
x1 = x1.reshape(-1, 1)
x2 = x2.reshape(-1, 1)   



        
model = PhysicsInformedNN(X_u_train, u_train, layers, lb, ub)
initial_weights, initial_biases = model.get_initial()
start_time = time.time()             
loss_set = model.train(5000)
elapsed = time.time() - start_time                
print('Training time: %.4f' % (elapsed))
    
u1_pred = model.predict(x1)
u2_pred = model.predict(x2)
u4_pred = model.predict(-x1)

u1_pred_flat = u1_pred.flatten()
u2_pred_flat = u2_pred.flatten()
u4_pred_flat = u4_pred.flatten()



S =  np.linalg.norm(u1_pred_flat - u4_pred_flat,2)/np.linalg.norm(u1_pred_flat,2) 
error_u1 = np.linalg.norm(u1_star - u1_pred_flat,2)/np.linalg.norm(u1_star,2)
error_u2 = np.linalg.norm(u2_star - u2_pred_flat,2)/np.linalg.norm(u2_star,2)
print('Error u1: %e' % (error_u1))
print('Error u2: %e' % (error_u2))
print('S: %e' % (S)) 
trained_weights, trained_biases = model.sess.run([model.weights, model.biases])                     

# xxxx = 1.5
# Exact = solution(xxxx, tttt)
# XXXX_star = np.column_stack((np.full(tttt.shape, xxxx), tttt))
# u_pred, f_pred = model.predict(XXXX_star)

# tttt1 = 0.5
# xxxx1 = np.linspace(0, 2, 201)
# Exact_cross_1 = solution(xxxx1, tttt1)
# XXXX1_star = np.column_stack((xxxx1, np.full(xxxx1.shape, tttt1)))
# u_pred_cross1, f_pred_cross1 = model.predict(XXXX1_star)


# tttt2 = -0.5
# xxxx2 = np.linspace(-2, 0, 201)
# Exact_cross_2 = solution(xxxx2, tttt2)
# XXXX2_star = np.column_stack((xxxx2, np.full(xxxx2.shape, tttt2)))
# u_pred_cross2, f_pred_cross2 = model.predict(XXXX2_star)

# U1_pred = griddata(X1_star, u1_pred.flatten(), (X1, T1), method='cubic')
# Error1 = np.abs(Exact1 - U1_pred)
# U2_pred = griddata(X2_star, u2_pred.flatten(), (X2, T2), method='cubic')
# Error2 = np.abs(Exact2 - U2_pred)

