# -*- coding: utf-8 -*-
"""
Created on Thu Apr  4 15:02:44 2024

@author: HP
"""

import sys
sys.path.insert(0, '../../Utilities/')
import tensorflow as tf
import numpy as np
from numpy import eye
from pyDOE import lhs
import time


n=5
r=1001
# r=2002
# r=3003
# r=4004
# r=5005
N_u = 100
N_f = 100
layers = [2, n, n, n, 1]
def solution(X, T):
    return (X + T)/(X*T + 1)


t1 = np.linspace(1/2, 1, 101)
x1 = np.linspace(1/2, 1, 101)
t2 = np.linspace(1, 2, 201)
x2 = np.linspace(1, 2, 201)


X1,  T1 = np.meshgrid(x1,t1)
X2,  T2 = np.meshgrid(x2,t2)   
u1 = solution(X1, T1)
u2 = solution(X2, T2)
Exact1 = u1
Exact2 = u2
X1_star = np.hstack((X1.flatten()[:,None], T1.flatten()[:,None]))
X2_star = np.hstack((X2.flatten()[:,None], T2.flatten()[:,None]))
u1_star = Exact1.flatten()[:,None]
u2_star = Exact2.flatten()[:,None]
X3_star = np.reciprocal(X1_star)

np.random.seed(r)
tf.set_random_seed(r)

class PhysicsInformedNN:
    # Initialize the class
    def __init__(self, X_u, u, X_f, layers, lb, ub):
        #boundary conditions
        self.lb = lb
        self.ub = ub
    
        
        #data
        self.x_u = X_u[:,0:1]
        self.t_u = X_u[:,1:2]
        
        self.x_f = X_f[:,0:1]
        self.t_f = X_f[:,1:2]
        
        self.u = u
        
        self.layers = layers
        self.loss_set =[]
        
        # Initialize NNs
        self.weights, self.biases = self.initialize_NN(layers)
        
        # tf placeholders and graph
        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                     log_device_placement=True))
        
        self.x_u_tf = tf.placeholder(tf.float32, shape=[None, self.x_u.shape[1]])
        self.t_u_tf = tf.placeholder(tf.float32, shape=[None, self.t_u.shape[1]])        
        self.u_tf = tf.placeholder(tf.float32, shape=[None, self.u.shape[1]])
        
        self.x_f_tf = tf.placeholder(tf.float32, shape=[None, self.x_f.shape[1]])
        self.t_f_tf = tf.placeholder(tf.float32, shape=[None, self.t_f.shape[1]])        
                
        self.u_pred = self.net_u(self.x_u_tf, self.t_u_tf)
        self.f_pred = self.net_f(self.x_f_tf, self.t_f_tf)         
        
        self.loss = tf.reduce_mean(tf.square(self.u_tf - self.u_pred))  + \
                    tf.reduce_mean(tf.square(self.f_pred))  

        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss, 
                                                                method = 'L-BFGS-B', 
                                                                options = {'maxiter': 50000,
                                                                           'maxfun': 50000,
                                                                           'maxcor': 50,
                                                                           'maxls': 50,
                                                                           'ftol' : 1.0 * np.finfo(float).eps})
        
        self.optimizer_Adam = tf.train.AdamOptimizer()
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)
        
        init = tf.global_variables_initializer()
        self.sess.run(init)

    def initialize_NN(self, layers):        
        weights = []
        biases = []
        num_layers = len(layers) 
        for l in range(0,num_layers-1): 
            if l==0 or l == num_layers-2:
                W = self.xavier_init(size=[layers[l], layers[l+1]])
            else:
                W = self.xavier_init(size=[layers[l]*2, (layers[l+1])])
            b = tf.Variable(tf.zeros([1,layers[l+1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W) 
            biases.append(b)  
        return weights, biases
        
    def xavier_init(self, size):
        in_dim = size[0] 
        out_dim = size[1]
        xavier_stddev = np.sqrt(2/(in_dim + out_dim))
        return tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)
    
    def get_initial(self):
        initial_weights, initial_biases = self.sess.run([self.weights, self.biases])
        return initial_weights, initial_biases
    
    def neural_net(self, X, weights, biases):
        num_layers = len(weights) + 1
        X_inverse = tf.reciprocal(X) 
        H = X
        for l in range(0,num_layers-2):
            if l == 0:
                W = weights[l] 
                b = biases[l] 
                b = tf.matmul(b, BM6)
                H = tf.tanh(tf.add(tf.concat([tf.matmul(X,W), tf.matmul(X_inverse,W)], axis=1), b))
            else:
                W = weights[l] 
                b = biases[l] 
                b = tf.matmul(b, BM6)
                W = tf.add(tf.matmul(W, BM2), tf.matmul(BM3, tf.matmul(W,BM4)))
                H = tf.tanh(tf.add(tf.matmul(H, W), b)) 
        W = weights[-1] 
        b = biases[-1] 
        Y = tf.matmul(H, tf.matmul(BM5, W))
        return Y
    
    def net_u(self, x, t):
        u = self.neural_net(tf.concat([x,t],1), self.weights, self.biases)
        return u
    
    def net_f(self, x,t):
        u = self.net_u(x,t)
        u_t = tf.gradients(u, t)[0]
        u_x = tf.gradients(u, x)[0]
        u_xx = tf.gradients(u_x, x)[0]
        u_xxx = tf.gradients(u_xx, x)[0]
        f = u_t + u*u_x + u_xxx - ( -t**4*x - 6*t**4 - t**3*x**2 - t**3 - t**2*x**4 + t**2*x**2 + 6*t**2 - 2*t*x**3 + t*x**2 + 2*t*x + t - x**2 + x + 1)/(t*x + 1)**4
        return f
    
    def callback(self, loss):
        print('Loss:', loss)
        self.loss_set.append(loss)
    
    
    
    def train(self, nIter):
        tf_dict = {self.x_u_tf: self.x_u, self.t_u_tf: self.t_u, self.u_tf: self.u,
                    self.x_f_tf: self.x_f, self.t_f_tf: self.t_f}    
        for it in range(nIter):
            self.sess.run(self.train_op_Adam, tf_dict)
            
            # Print
            if it % 10 == 0:
                loss_value = self.sess.run(self.loss, tf_dict)
                print('It: %d, Loss: %.3e' % 
                      (it, loss_value))
                                                                                                                          
        self.optimizer.minimize(self.sess, 
                                feed_dict = tf_dict,         
                                fetches = [self.loss], 
                                loss_callback = self.callback)   
                                      
        loss_set = self.loss_set
        return  loss_set
         
    
    def predict(self, X_star):
                
        u_star = self.sess.run(self.u_pred, {self.x_u_tf: X_star[:,0:1], self.t_u_tf: X_star[:,1:2]})  
        f_star = self.sess.run(self.f_pred, {self.x_f_tf: X_star[:,0:1], self.t_f_tf: X_star[:,1:2]})
               
        return u_star, f_star


identity_matrix  = tf.eye(layers[1], dtype=tf.float32)
zero_matrix = tf.zeros((layers[1], layers[1]), dtype=tf.float32)
BM0 = eye(layers[0])[::-1]
BM0 = tf.concat([BM0, BM0], axis=0)
BM0 = tf.cast(BM0, dtype=tf.float32)
BM1 = tf.concat([identity_matrix, identity_matrix], axis=1)
BM2 = tf.concat([identity_matrix, zero_matrix], axis=1)
BM3 = tf.concat([tf.concat([zero_matrix, identity_matrix], axis=1),
                 tf.concat([identity_matrix, zero_matrix], axis=1)], axis=0)
BM4 = tf.concat([zero_matrix, identity_matrix], axis=1)
BM5 = tf.concat([identity_matrix, identity_matrix], axis=0)
BM6 = tf.concat([identity_matrix, identity_matrix], axis=1)


# Doman bounds
lb = X1_star.min(0)
ub = X1_star.max(0)  


xx1 = np.hstack((X1[0:1,:].T, T1[0:1,:].T))
uu1 = Exact1[0:1,:].T
xx2 = np.hstack((X1[:,0:1], T1[:,0:1]))
uu2 = Exact1[:,0:1]
xx3 = np.hstack((X1[:,-1:], T1[:,-1:]))
uu3 = Exact1[:,-1:]

X_u_train = np.vstack([xx1, xx2, xx3])
u_train = np.vstack([uu1, uu2, uu3])
    
X_f_train = lb + (ub-lb)*lhs(2, N_f)
X_f_train = np.vstack((X_f_train, X_u_train))
idx = np.random.choice(X_u_train.shape[0], N_u, replace=False)
X_u_train = X_u_train[idx, :]
u_train = u_train[idx,:]

        
model = PhysicsInformedNN(X_u_train, u_train, X_f_train, layers, lb, ub)
initial_weights, initial_biases = model.get_initial()
start_time = time.time()             
loss_set = model.train(0)
elapsed = time.time() - start_time                
print('Training time: %.4f' % (elapsed))
    
u1_pred, f1_pred = model.predict(X1_star)
u2_pred, f2_pred = model.predict(X2_star)
u3_pred, f3_pred = model.predict(X3_star)
S =  np.linalg.norm(u1_pred - u3_pred,2)/np.linalg.norm(u1_pred,2) 
error_u1 = np.linalg.norm(u1_star - u1_pred,2)/np.linalg.norm(u1_star,2)
error_u2 = np.linalg.norm(u2_star - u2_pred,2)/np.linalg.norm(u2_star,2)
print('Error u1: %e' % (error_u1))
print('Error u2: %e' % (error_u2))
print('S: %e' % (S)) 
trained_weights, trained_biases = model.sess.run([model.weights, model.biases])                     

    
# U1_pred = griddata(X1_star, u1_pred.flatten(), (X1, T1), method='cubic')
# Error1 = np.abs(Exact1 - U1_pred)
# U2_pred = griddata(X2_star, u2_pred.flatten(), (X2, T2), method='cubic')
# Error2 = np.abs(Exact2 - U2_pred)

# xxxx1 = np.linspace(1/2, 1, 101)
# tttt1 = 2/3
# Exact1_Cross_section = solution(xxxx1, tttt1)
# XXXX1_star = np.column_stack((xxxx1, np.full(xxxx1.shape, tttt1)))
# u1_Cross_section, f_1 = model.predict(XXXX1_star)

# xxxx2 = np.linspace(1, 2, 201)
# tttt2 = 3/2
# Exact2_Cross_section = solution(xxxx2, tttt2)
# XXXX2_star = np.column_stack((xxxx2, np.full(xxxx2.shape, tttt2)))
# u2_Cross_section, f_2 = model.predict(XXXX2_star)

# tttt1 = np.linspace(1/2, 1, 101)
# xxxx1 = 2/3
# Exact1_Cross_section = solution(xxxx1, tttt1)
# XXXX1_star = np.column_stack((np.full(tttt1.shape, xxxx1), tttt1))
# u1_Cross_section, f_1 = model.predict(XXXX1_star)

# tttt2 = np.linspace(1, 2, 201)
# xxxx2 = 3/2
# Exact2_Cross_section = solution(xxxx2, tttt2)
# XXXX2_star = np.column_stack((np.full(tttt2.shape, xxxx2) ,tttt2))
# u2_Cross_section, f_2 = model.predict(XXXX2_star)
